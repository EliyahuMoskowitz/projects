export interface Error{
  cod: number;
  message: string;
}
