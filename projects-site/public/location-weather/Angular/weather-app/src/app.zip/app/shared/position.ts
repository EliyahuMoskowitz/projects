export interface Position{
    longitude: number;
    latitude: number;
}

export interface PositionCoords{
  coords:{
    longitude: number;
    latitude: number;
  }
}
